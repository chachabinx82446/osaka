
// Simple PWA Service Worker
const STATIC_CACHE = 'static-v1';
const STATIC_ASSETS = [
  './index.html',
  './offline.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './assets/og-image.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== STATIC_CACHE).map(k => caches.delete(k))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const req = event.request;

  // HTML: network-first, fallback to cache, then offline page
  if (req.headers.get('accept')?.includes('text/html')) {
    event.respondWith((async () => {
      try {
        const net = await fetch(req);
        const cache = await caches.open(STATIC_CACHE);
        cache.put(req, net.clone());
        return net;
      } catch (e) {
        const cache = await caches.open(STATIC_CACHE);
        const cached = await cache.match(req);
        return cached || await cache.match('./offline.html');
      }
    })());
    return;
  }

  // Other: cache-first, then network
  event.respondWith((async () => {
    const cache = await caches.open(STATIC_CACHE);
    const cached = await cache.match(req);
    if (cached) return cached;
    try {
      const net = await fetch(req);
      cache.put(req, net.clone());
      return net;
    } catch (e) {
      if (req.mode === 'navigate') {
        return await cache.match('./offline.html');
      }
      throw e;
    }
  })());
});
